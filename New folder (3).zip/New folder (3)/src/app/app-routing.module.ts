import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShareCompComponent } from './share-comp/share-comp.component';
const routes: Routes = [
  { path: 'drop', component: ShareCompComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
