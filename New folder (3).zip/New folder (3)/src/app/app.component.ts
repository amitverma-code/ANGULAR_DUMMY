import { Component } from '@angular/core';
import { ShareCompComponent } from './share-comp/share-comp.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Hi';
}
