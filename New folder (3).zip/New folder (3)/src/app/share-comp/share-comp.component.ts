import { Component, OnInit } from '@angular/core';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
@Component({
  selector: 'app-share-comp',
  templateUrl: './share-comp.component.html',
  styleUrls: ['./share-comp.component.css']
})
export class ShareCompComponent implements OnInit {
  dropdownList = [];
  selectedItems = [];
  dropdownSettings:IDropdownSettings;
  dropdownList1 = [];
  selectedItems1 = [];
  constructor() { }

  ngOnInit() {
    this.dropdownList = [
      { item_id: 1, item_text: 'FUSO eCanter' },
      { item_id: 2, item_text: 'FUSO eFighter' },
      { item_id: 3, item_text: 'FC SuperGreat' },
      { item_id: 4, item_text: 'eActros Gen3' },
      { item_id: 5, item_text: 'eConstruction' }
    ];
    this.selectedItems = [
    ];
    this.dropdownSettings= {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
    this.dropdownList1 = [
     
      { item_id: 1, item_text: 'eAxleSpecific' },
      { item_id: 2, item_text: 'BatterySpecific' },
      { item_id: 3, item_text: 'ChargingSpecific' },
      { item_id: 4, item_text: 'Powernet' },
      { item_id: 5, item_text: 'Feedback' },
      { item_id: 6, item_text: 'VehicleSpecific' }
    ];
    this.selectedItems1 = [
    ];
  }
  onItemSelect(item: any) {
    console.log(item);
  }
  onSelectAll(items: any) {
    console.log(items);
  }

}
