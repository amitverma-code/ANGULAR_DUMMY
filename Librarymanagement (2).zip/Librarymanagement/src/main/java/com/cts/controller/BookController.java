package com.cts.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.entity.Book;
import com.cts.service.BookService;

@RestController
@RequestMapping("/book")
public class BookController {

	@Autowired
	private BookService bookService;

	@GetMapping
	private List<Book> getAll() {
		return bookService.getAll();
	}
	
	@GetMapping("/{id}")
	private Book getById(@PathVariable int id){
		return bookService.getById(id);
	}
	
	@PostMapping
	private Book add(@Valid @RequestBody Book book){
		return bookService.addOrUpdate(book);
	}
	
	@PutMapping("/{id}")
	private Book update(@PathVariable int id,@RequestBody Book book){
		book.setBookId(id);
		return bookService.addOrUpdate(book);
	}
    
	@DeleteMapping("/{id}")
	private void delete(@PathVariable int id){
	bookService.deleteById(id);
}
	
	@GetMapping("/test")
	public Page<Book> fetchByPage(Pageable page){
		return this.bookService.findAllByPage(page);
		//fix page=1 instead of page =0
		//sort (asc/desc)
	
}
}