package com.cts.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.entity.Author;
import com.cts.entity.Book;
import com.cts.service.AuthorService;
import com.cts.service.BookService;


@RestController
@RequestMapping("/author")
public class AuthorController {

	
	@Autowired
	private AuthorService authorService;

	@GetMapping
	private List<Author> getAll() {
		return authorService.getAll();
	}
	
	@GetMapping("/{id}")
	private Author getById(@PathVariable int id){
		return authorService.getById(id);
	}
	
	@PostMapping
	private Author add(@Valid @RequestBody Author author){
		return authorService.addOrUpdate(author);
	}
	
	@PutMapping("/{id}")
	private Author update(@PathVariable int id,@RequestBody Author author){
		author.setAuthorId(id);
		return authorService.addOrUpdate(author);
	}
    
	@DeleteMapping("/{id}")
	private void delete(@PathVariable int id){
	authorService.deleteById(id);
}
}
