package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.Author;

import com.cts.repository.AuthorRepository;

@Service
public class AuthorService {
	
	
		@Autowired
		private AuthorRepository authorRepository;
		
		public Author addOrUpdate(Author author){
	        return authorRepository.save(author);
	    }
		public boolean deleteById(int id){
			authorRepository.deleteById(id);
			return true;
		}
		public List<Author> getAll(){
			return authorRepository.findAll();
		}
	    
		public Author getById(int id){
			return authorRepository.findById(id).get();
		}
}
