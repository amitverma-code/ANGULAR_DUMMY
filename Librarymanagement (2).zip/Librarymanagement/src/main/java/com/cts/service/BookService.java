package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.cts.entity.Book;
import com.cts.repository.BookRepository;

@Service
public class BookService {
	@Autowired
	private BookRepository bookRepository;
	
	public Book addOrUpdate(Book book){
        return bookRepository.save(book);
    }
	public boolean deleteById(int id){
		bookRepository.deleteById(id);
		return true;
	}
	public List<Book> getAll(){
		return bookRepository.findAll();
	}
    
	public Book getById(int id){
		return bookRepository.findById(id).get();
	}
	
	public Page<Book> findAllByPage(Pageable pageable){
		return bookRepository.findAll(pageable);
	}
	public Page<Book> findAllByPageOrderByidDesc(Pageable page) {
		// TODO Auto-generated method stub
		return null;
	}
	public Page<Book> findAllByPageOrderByidAsc(Pageable page) {
		// TODO Auto-generated method stub
		return null;
	}
}
